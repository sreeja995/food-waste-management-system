<h2 align="center">FoodYard</h2>
<div align="center">
<p>A food waste management website project created using HTML, CSS and JavaScript.</p>
<a href="https://mohdrahil101.github.io/FoodYard/" target="_blank"><strong>➥ Live Demo</strong></a>
</div> <br/><br/>
